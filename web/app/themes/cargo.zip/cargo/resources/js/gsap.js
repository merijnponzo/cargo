import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { SplitText } from 'gsap/SplitText'
gsap.registerPlugin(ScrollTrigger)

export const siteGsap = () => {
	gsap.defaults({ ease: 'none' })
	ScrollTrigger.matchMedia({
		// desktop
		'(min-width: 1024px)': function () {
			let banners = document.querySelectorAll('.p-parra')
			banners.forEach((element) => {
				gsap.to(element, {
					scrollTrigger: {
						scrub: true,
					},
					y: (i, target) =>
						-ScrollTrigger.maxScroll(window) * target.dataset.yspeed,
					x: (i, target) =>
						-ScrollTrigger.maxScroll(window) * target.dataset.xspeed,
					ease: 'none',
				})
			})
		},
		// mobile
		'(max-width: 1024px)': function () {
			let banners = document.querySelectorAll('.p-parra')
			banners.forEach((element) => {
				gsap.to(element, {
					scrollTrigger: {
						scrub: true,
					},
					y: (i, target) =>
						ScrollTrigger.maxScroll(window) * target.dataset.yspeed,
					x: (i, target) =>
						-ScrollTrigger.maxScroll(window) * target.dataset.xspeed,
					ease: 'none',
				})
			})
		},
	})

	// batch scroll trigger
	ScrollTrigger.batch('.p-view', {
		start: 'top bottom-=100px',
		toggleActions: 'play none none reverse',
		start: 'top bottom-=100',
		toggleClass: 'in',
	})

	document.fonts.ready.then((fontFaceSet) => {
		const childSplit = new SplitText('.p-line', { type: 'lines' })
		gsap.set(childSplit.lines, { opacity: 0 })
		ScrollTrigger.batch(childSplit.lines, {
			onEnter: (batch) => {
				gsap.set(batch, { opacity: 0, yPercent: 100 })
				gsap.to(batch, {
					yPercent: 5,
					duration: 1,
					opacity: 1,
					ease: 'power4',
					stagger: 0.2,
				})
			},
			onLeaveBack: (batch) => gsap.to(batch, { opacity: 0, yPercent: 100 }),
			start: 'bottom 95%',
		})
	})

	// scrollbar
	const header = document.querySelector('header')
	if (header) {
		const toolBar = gsap
			.from(header, {
				yPercent: -100,
				paused: true,
				duration: 0.2,
			})
			.progress(1)

		ScrollTrigger.create({
			start: 'top top',
			end: 99999,
			onUpdate: (self) => {
				if (
					self.direction === -1 &&
					self.progress > 0.0012300123001230013
				) {
					header.classList.add('scrolled-in')
				} else {
					header.classList.remove('scrolled-in')
				}
				self.direction === -1 ? toolBar.play() : toolBar.reverse()
			},
		})
	}
}

export default siteGsap
