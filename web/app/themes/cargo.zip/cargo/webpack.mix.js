const mix = require("laravel-mix");
require("tailwindcss")
require("laravel-mix-clean");
// generate mix
mix.setPublicPath("./");
// theme
const path = "dist/";
const developmentFolder = 'blocks-theme-dev';



mix.js(`${developmentFolder}/js/ponzo-editor.js`, path) 
   .babelConfig({
       plugins: ['@babel/plugin-transform-modules-commonjs']
   });

mix.js(`${developmentFolder}/js/ponzo-frontend.js`, path);

mix.postCss(`${developmentFolder}/css/ponzo-editor.css`, "dist", [
  require("tailwindcss")(`${developmentFolder}/tailwind-editor.config.js`),
]);
mix.postCss(`${developmentFolder}/css/ponzo-editor-ui.css`, "dist", [
  require("tailwindcss")(`${developmentFolder}/tailwind.config.js`),
]);
mix.postCss(`${developmentFolder}/css/ponzo-frontend.css`, "dist", [
  require("tailwindcss")(`${developmentFolder}/tailwind.config.js`),
]);

mix.js("./resources/js/main.js", path);
mix.postCss("./resources/css/main.css", "dist", [
  require("tailwindcss")(`${developmentFolder}/tailwind.config.js`),
]);


mix.copy('blocks-theme-dev/ponzoblocks.php', 'site');

mix.options({
  processCssUrls: false,
});

mix.webpackConfig({
  stats: {
    children: true,
  },
});
// build
if (mix.inProduction()) {
  /* be carefull, since the default settings could erase your entire project */
  mix.clean({
    cleanOnceBeforeBuildPatterns: ["./dist/*"],
  });
  // create manifest
  mix.version();
  mix.then(() => {
    const convertToFileHash = require("laravel-mix-make-file-hash");
    convertToFileHash({
      publicPath: "./",
      manifestFilePath: "mix-manifest.json",
      blacklist:"ponzoblocks.php"
    });
  });
}
mix.browserSync({
  watch: true,
  proxy: process.env.MIX_APP_HOST,
  host: process.env.MIX_APP_HOST,
  files: [
    "./**/*.php",
    "./**/*.html",
    "./resources/**/*.css",
    "./resources/**/*.js",
    "./blocks-custom/**/*.css",
    "./blocks-custom/**/*.js"
  ],
});
