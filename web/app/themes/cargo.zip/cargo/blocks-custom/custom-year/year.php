<?php 
$year = date('Y');
echo $year;
?>