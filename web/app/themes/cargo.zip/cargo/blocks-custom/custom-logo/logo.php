<a href="/" title="Home">
    <svg class="site-logo" width="742" height="auto" viewBox="0 0 742 261" fill="none" xmlns="https://www.w3.org/2000/svg">
        <path d="M174 80.3115H228.395V250.602H174V80.3115Z" fill="#19DB71" />
        <path fill-rule="evenodd" clip-rule="evenodd" d="M332.572 165.576L289.39 80.3115H235.154L278.336 165.576L235.154 250.841H289.39L332.572 165.576Z" fill="#19DB71" />
        <path fill-rule="evenodd" clip-rule="evenodd" d="M386.807 165.576L429.989 80.3115H375.753L332.571 165.576L375.753 250.841H429.989L386.807 165.576Z" fill="#19DB71" />
        <path d="M683.274 185.02C676.673 196.973 665.54 205.34 648.362 205.34C633.571 205.34 614.803 196.733 612.497 174.66H728.046C728.682 169.72 729 164.779 729 160.157C729 108.042 691.465 80.6302 649.635 80.6302C598.898 80.6302 564.703 117.286 564.703 165.735C564.703 216.575 605.181 250.841 648.681 250.841C671.584 250.841 691.544 243.031 706.654 230.122L683.274 185.02ZM646.692 120.553C662.836 120.553 677.309 128.123 679.934 145.654H612.815C617.348 125.812 634.843 120.553 646.692 120.553Z" fill="#19DB71" />
        <path d="M519.931 183.665V124.139H558.102L580.369 80.0725H436.032V124.139H466.093V198.327C466.093 230.76 488.598 250.92 520.646 250.92H558.023V203.826H539.732C525.736 203.826 519.931 198.008 519.931 183.665Z" fill="#19DB71" />
        <path d="M466.649 113.063L519.374 86.2084V9.39062L466.649 36.245V113.063Z" fill="#19DB71" />
        <path d="M174 80.3912L228.554 52.5807V7L174 34.7309V80.3912Z" fill="currentColor" />
        <path d="M605.817 80.3912L660.371 52.5807V7L605.817 34.7309V80.3912Z" fill="currentColor" />
        <path d="M13 225L108 170.054V80L13 134.788V225Z" fill="#19DB71" />
        <g filter="url(#filter0_b_148_2)">
            <path d="M60 251L154 196.054V106L60 160.788V251Z" fill="#80A1A9" fill-opacity="0.5" />
        </g>
        <defs>
            <filter id="filter0_b_148_2" x="45" y="91" width="124" height="175" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                <feFlood flood-opacity="0" result="BackgroundImageFix" />
                <feGaussianBlur in="BackgroundImageFix" stdDeviation="7.5" />
                <feComposite in2="SourceAlpha" operator="in" result="effect1_backgroundBlur_148_2" />
                <feBlend mode="normal" in="SourceGraphic" in2="effect1_backgroundBlur_148_2" result="shape" />
            </filter>
        </defs>
    </svg>
</a>