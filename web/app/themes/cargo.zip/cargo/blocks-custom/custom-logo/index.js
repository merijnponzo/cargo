(function (wp) {

const ServerSideRender = wp.serverSideRender;
const blockName = "ponzoblocks/custom-logo";

const { registerBlockType } = wp.blocks;
const { createElement } = wp.element;

registerBlockType(blockName, {
	title: "Custom Logo",
	description: "A custom logo blocktype.",
	category: "ponzoblocks",
	edit(props) {
		return createElement(ServerSideRender, {
			block: blockName,
			attributes: props.attributes,
		})
	},
	save() {
		return null;
	},
});
})(window.wp);