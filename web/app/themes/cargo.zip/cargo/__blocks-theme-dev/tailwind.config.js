/*
  Styles should only be generated from theme.json
*/
const config = require("./tailwind/config.default.js");


module.exports = { ...config.config };
