import {
	InnerBlocks,
	useBlockProps,
	useInnerBlocksProps,
} from '@wordpress/block-editor'

import ResponsiveImage from '../../helpers/responsiveImage'
import ResponsiveVideo from '../../helpers/responsiveVideo'

export default function save({ attributes }) {
	const {
		linkUrl,
		linkTitle,
		linkTarget,
		linkTile,
		media,
		imageProps,
		imageClass,
		customClass,
		customFlexClass,
	} = attributes

	/* should be refactored to ponzoClass helpers! */
	const blockProps = useBlockProps.save({
		className: `relative ${customClass}`,
	})

	// set innerBlockProps classes
	const { children, ...innerBlocksProps } = useInnerBlocksProps.save({
		className: `group--content  flex relative z-10 h-full w-full ${customFlexClass}`,
	})

	return (
		<div {...blockProps}>
			<div {...innerBlocksProps}>{children}</div>
			{media.id ? (
				<div className="group--video absolute left-0 top-0 w-full h-full z-0">
					{media.type === 'video' ? (
						<ResponsiveVideo
							media={media}
							imageClass={imageClass}
							extraClass={'absolute left-0 top-0 w-full h-full z-0'}
						/>
					) : (
						<ResponsiveImage
							media={media}
							imageClass={imageClass}
							extraClass={'absolute left-0 top-0 w-full h-full z-0'}
						/>
					)}
				</div>
			) : null}
			{linkUrl ? (
				<a
					rel="noopener noreferrer"
					target={linkTarget}
					href={linkUrl}
					title={linkTitle}
					className="tile"
				></a>
			) : null}
		</div>
	)
}
