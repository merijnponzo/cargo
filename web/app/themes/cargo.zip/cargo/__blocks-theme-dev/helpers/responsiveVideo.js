// fix
export default function ResponsiveVideo(props) {
  const { media, imageClass, extraClass } = props;
  const { url, alt } = media;

  let videoUrl = url;

  const videoClass = imageClass ? `responsive-video ${imageClass}` : "responsive-video";

  return (
    <video className={videoClass} id="player" playsinline controls autoplay muted loop>
      <source src={videoUrl} type="video/mp4" />
    </video>
  );
}
