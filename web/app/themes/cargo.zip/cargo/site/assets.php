<?php

namespace App\Assets;


class siteAssets
{

	public $assets =  [];
	public $manifest = false;
	public $dir = false;
	public $uri = false;
	public $version = '1.0.3';
	public $admin = false;
	public $jit_browser = '';

	// create a construct where the manifest file is loaded and decoded
	public function __construct()
	{

		$this->dir = get_template_directory();
		$this->uri = get_template_directory_uri();
		$this->version = '1.02';
		$this->manifest = $this->manifest_assets();
		
		$default_assets = [
			[
				'name' => 'alpine',
				'type' => 'js',
				'file' => 'https://cdn.jsdelivr.net/npm/alpinejs@3.12.0/dist/cdn.min.js'

			]
		];
		if (is_admin()) {
			// add blockstyles
			$default_assets[] =
				[
					'name' => 'theme-blockstyles',
					'type' => 'js',
					'file' => $this->uri . '/blocks-custom/block-styles.js'
				];
		}

		// get all assets in array and merge
		$this->assets = array_merge($default_assets, $this->manifest_assets());

		// add add_jit_browser (tailwind compiled from browser)
		if (current_user_can('editor') || current_user_can('administrator')) {
			add_action('admin_init', array($this, 'enqeue_admin_assets'));
		} 
		add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));


		// self::is_dev();
	}

	public function manifest_assets()
	{

		$files = $this->get_manifest();
		$manifestAssets = [];

		foreach ((array) $files as $name => $asset) {
			if (isset($asset)) {
				// get extension of $file by stripping end
				$ext = substr($asset, strrpos($asset, '.') + 1);

				$file = [
					'name' => $name,
					'type' => $ext,
					'manifest' => true,
					'file' => "{$this->uri}{$asset}"
				];
				$manifestAssets[] = $file;
			}
		}
		return $manifestAssets;
	}
	// get manifest file
	public function get_manifest()
	{
		// default manifest
		$manifest_file = $this->dir . '/mix-manifest.json';
		if (file_exists($manifest_file)) {
			return  json_decode(file_get_contents($manifest_file), true);
		} else {
			throw new Exception($manifest_file, 'is not found found');
		}
	}
	// load assets from cdn or manifest
	public function enqueue_assets()
	{

		
		foreach ((array) $this->assets as $asset) {
			// versioning
			if(WP_ENV !== null && WP_ENV == 'production') {
				$version = null;
			}	else {
				$version = rand(1, 100);
			}
			

			if ($asset['type'] == 'js') {
				wp_enqueue_script($asset['name'], $asset['file'], [], $version);
			} else if ($asset['type'] == 'css') {
				// dont load editor styles
				if ($asset['name'] !== '/dist/ponzo-editor.css') {
					wp_enqueue_style($asset['name'], $asset['file'], [], $version);
				}	
			}
		}
	}
	// add editor styles
	function enqeue_admin_assets()
	{
		$editor_styles = [];

		foreach ((array) $this->assets as $asset) {
			if(WP_ENV !== null && WP_ENV == 'production') {
				$version = null;
			}	else {
				$version = rand(1, 100);
			}

			if ($asset['type'] == 'js') {
				wp_enqueue_script($asset['name'], $asset['file'], [],$version);
			} else if ($asset['type'] == 'css') {
				if($asset['name'] == '/dist/ponzo-editor-ui.css'){
					wp_enqueue_style($asset['name'], $asset['file'], [], $version);
				} else if($asset['name'] === '/dist/ponzo-editor.css'){
					$editor_styles[] = $asset['file'];
				} else {
					$editor_styles[] = $asset['file'];
				}
			}
		}
		add_editor_style($editor_styles);
	}


}
