<?php

function ponzo_wpml_menu(){
    do_action( 'wpml_add_language_selector' );
}