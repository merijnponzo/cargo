<?php

/**
 * Title: Page
 * Slug: custom/pages
 * Categories: buroponzo
 */

?>
<!-- wp:post-content  /-->