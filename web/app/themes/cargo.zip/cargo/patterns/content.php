<?php

/**
 * Title: 404
 * Slug: custom/404
 * Categories: buroponzo
 */

 if ( is_404() ) {
    var_dump('404');
  }
