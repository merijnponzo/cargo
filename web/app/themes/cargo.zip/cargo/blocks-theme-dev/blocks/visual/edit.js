import {
  InnerBlocks,
  useBlockProps,
  useInnerBlocksProps,
  InspectorControls,
  BlockControls,
} from "@wordpress/block-editor";

import {
  PanelBody,
  PanelRow,
  RangeControl,
  ToggleControl,
  Button,
  SelectControl,
} from "@wordpress/components";

import { useState, useEffect } from "@wordpress/element";

import {
  shrink,
  shapes,
  dimension,
  rotation,
  padding,
  margin,
  transformScale,
  transformPosition,
  rounded,
  shadow,
  zIndex,
  order,
  position,
  positionMove
} from "../../helpers/customStyles";
import CustomStylePanel from "../../helpers/customStylePanel";
import CustomImagePanel from "../../helpers/customImagePanel";
import CustomCopyPanel from "../../helpers/customCopyPanel";
import ResponsiveImage from "../../helpers/responsiveImage";

import { PonzoImageSmall } from "../../assets/PonzoIcons";

export default function Edit({ attributes, setAttributes, clientId }) {
  const {
    blockId,
    media,
    imageProps,
    imageClass,
    customStyle,
    customClass,
    isBanner,
  } = attributes;


  useEffect(() => {
    if (!blockId) {
      setAttributes({ blockId: clientId });
    }
  }, []);

  // get custom style settings
  const customStyleSettings = [
    shrink,
    order,
    shapes,
    rotation,
    dimension,
    transformScale,
    transformPosition,
    padding,
    margin,
    rounded,
    shadow,
    zIndex,
    position,
    positionMove
  ];

  const styleCallback = (styleObj, styleClass) => {
    setAttributes({
      customStyle: styleObj,
      customClass: styleClass,
    });
  };

  // handle image callback
  const handleImage = (media) => {
    setAttributes({
      media: media,
    });
  };

  const handleImageProps = (imageProps, imageClass) => {
    setAttributes({
      imageProps: { ...imageProps },
      imageClass: imageClass,
    });
  };

	const toggleBanner = () => {
		setAttributes({ isBanner: !isBanner })
	}

  // set classes
  const blockProps = useBlockProps({
    className: `overflow-hidden ${customClass}`,
  });

  // set inner blocks as banner wrapper
  const { children, ...innerBlocksProps } = useInnerBlocksProps({
    className:
      "z-10 absolute top-0 left-0 w-full h-full flex items-center justify-center",
  });


  return (
    <div {...blockProps}>
      <InspectorControls>
        <PanelBody title="Visual" initialOpen={true} icon={PonzoImageSmall}>
          <CustomImagePanel
            mediaProps={media}
            imageProps={imageProps}
            mediaCallback={(image) => handleImage(image)}
            imagePropsCallback={(imageProps, imageClass) => {
              handleImageProps(imageProps, imageClass);
            }}
          />
          <PanelRow>
            <ToggleControl
              label="Create banner"
              help={isBanner ? "Place text on visual" : "Only visual"}
              checked={isBanner}
              onChange={toggleBanner}
            />
          </PanelRow>
        </PanelBody>
        <CustomStylePanel
          defaultStyle={customStyle}
          styleSettings={customStyleSettings}
          parentCallback={(styleObj, styleClass) =>
            styleCallback(styleObj, styleClass)
          }
        />
        <CustomCopyPanel title="Copy & Paste Styles" />
      </InspectorControls>
      <ResponsiveImage
        media={media}
        imageClass={imageClass}
        extraClass={""}
        key={`visual_image__${blockId}`}
      />
      {isBanner ? <div {...innerBlocksProps}>{children}</div> : null}
    </div>
  );
}
